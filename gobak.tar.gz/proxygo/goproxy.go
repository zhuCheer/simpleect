package main

import (
	"github.com/zhuCheer/libra"
	"net/http"
)

func main() {
	go httpsrv01()
	go httpsrv02()
	go httpsrv03()
	var srv = libra.NewHttpProxySrv("127.0.0.1:5000", "roundrobin", nil)
	srv.GetBalancer().AddAddr("proxy.ks58.cc", "127.0.0.1:5001", 1)
	srv.GetBalancer().AddAddr("proxy.ks58.cc", "127.0.0.1:5002", 1)
	srv.GetBalancer().AddAddr("proxy.ks58.cc", "127.0.0.1:5003", 1)

	srv.Scheme = "http"
	srv.Start()
}

func httpsrv01() {

	mux := http.NewServeMux()
	mux.HandleFunc("/index", func(w http.ResponseWriter, r *http.Request) {
		pic := "<img src='http://104.168.125.218/p01.gif' />"
		w.Header().Set("Content-Type", "text/html; charset=UTF-8")
		w.Write([]byte("view http server 01<br>"+pic))
	})
	http.ListenAndServe("127.0.0.1:5001", mux)
}

func httpsrv02() {

	mux := http.NewServeMux()
	mux.HandleFunc("/index", func(w http.ResponseWriter, r *http.Request) {
	 	pic := "<img src='http://104.168.125.218/p02.gif' />"
		w.Header().Set("Content-Type", "text/html; charset=UTF-8")
		w.Write([]byte("view http server 02<br>"+pic))
	})
	http.ListenAndServe("127.0.0.1:5002", mux)
}

func httpsrv03() {

        mux := http.NewServeMux()
        mux.HandleFunc("/index", func(w http.ResponseWriter, r *http.Request) {
                pic := "<img src='http://104.168.125.218/p03.gif' />"
		w.Header().Set("Content-Type", "text/html; charset=UTF-8")
                w.Write([]byte("view http server 03<br>"+pic))
        })
        http.ListenAndServe("127.0.0.1:5003", mux)
}
