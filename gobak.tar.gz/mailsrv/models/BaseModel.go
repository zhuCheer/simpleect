package models


type BaseTable struct {

	Created_at          string `json:"created_at"`
	Updated_at          string `json:"updated_at"`

}

type BaseQueryParam struct {
	Sort   string `json:"sort"`
	Order  string `json:"order"`
	Offset int64  `json:"offset"`
	Limit  int    `json:"limit"`
}


var TableMap = map[string]string{
	"users":"qi_users",
	"apps":"qi_apps",
	"mailer":"qi_mailer",
}



