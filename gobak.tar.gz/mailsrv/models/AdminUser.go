package models

import (
	"github.com/astaxie/beego/orm"
	"mailsrv/utils"
)

type AdminUser struct {
	Id                 int
	Name           		string
	Email           	string
	Password            string
	Remember_token      string
	BaseTable
}

func (a *AdminUser) TableName() string {
	return TableMap["users"]
}

func ChangeAdminUserPwd(id int, pwd string) error{
	o := orm.NewOrm()
	user := AdminUser{}

	user.Id = id
	user.Password = utils.String2md5(pwd)
	user.BaseTable.Updated_at = utils.GetNowTime()

	_, err := o.Update(&user,  "Password", "Updated_at")
	return err
}



func GetOneAdminUser(name, password string)  (*AdminUser, error) {
	m := AdminUser{}

	err := orm.NewOrm().QueryTable(m.TableName()).Filter("name", name).Filter("password", password).One(&m)
	if err != nil {
		return nil, err
	}
	return &m, nil
}