package models

import (
	"github.com/astaxie/beego/orm"
	"github.com/astaxie/beego"
)


//初始化注册每一个表
func init() {
	beego.Notice("####init models######")
	orm.RegisterModel(new(AdminUser), new(Apps), new(Mailer))
}