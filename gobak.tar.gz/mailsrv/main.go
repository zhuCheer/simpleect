package main

import (
	_ "mailsrv/routers"
	"github.com/astaxie/beego"
	_ "mailsrv/sysyinit"
)

func main() {

	beego.SetLevel(beego.LevelInformational)
	beego.SetStaticPath("/static","static")
	beego.BConfig.Listen.HTTPAddr = "127.0.0.1"
	beego.Run()
}

