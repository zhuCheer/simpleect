# mailsrv
基于beego的邮件微服务后台
基本go的并发操作，并发处理邮件发送请求
发送邮件基于 [gomail](https://godoc.org/gopkg.in/gomail.v2)
前台界面基于 [kit_admin](https://gitee.com/besteasyteam/kit_admin)

## 安装前奏

 - GO 环境必不可少 GOPATH GOROOT 走一套，百度下咯；
 - 安装必要的依赖包
 
  ```
    go get github.com/astaxie/beego
	go get github.com/beego/bee
	go get -u github.com/go-sql-driver/mysql
	go get github.com/dchest/captcha
	go get github.com/axgle/mahonia
	go get gopkg.in/gomail.v2
  ```
  
  - 根目录下面有个mailsrv.sql 就是数据库，自己导入下，配置在conf/app.conf 改改；
  - 将本项目clone到src 目录（为什么是这个目录？ 刚开始就是为了了解他的加载模式，所以才这样弄得）
  - cd 到 mailsrv 目录下 执行 `../../bin/bee run` 启动beego 然后通过 http://localhost:8080就可以访问了；
  
  
  
## 接口请求说明

- 接口地址：
```
 /api/send-one 
```

- 接口类型：POST
- Body中添加参数（一个json）:

```
{
	"appid":"netbari",
	"to":["xxx@qq.com"],
	"cc":["xxx@qq.com"],
	"title":"Hello",
	"content":"Hello! what's going on！",
	"timestamp":1520587183,
	"sign":"85ebd2cdd457ede20ca2721bd8b17a7c"
}
```

- 其中有一个timestamp表示的是时间戳（s）
- 其中sign参数安装如下方式生成
```
md5(appid+timestamp+title+appkey) 
```
注意：appkey请到后台项目管理里面去看看，加密前的参数顺序不能乱；加号（+）只是连接字符，其实不存在。


  
  
## 演示查看
相关演示大家可以试试，不要乱修改噢。。。
[演示查看](/login) 密码，123456

