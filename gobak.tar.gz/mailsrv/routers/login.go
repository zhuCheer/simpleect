package routers

import (
	"mailsrv/controllers"
	"github.com/astaxie/beego"
	"github.com/dchest/captcha"
)


//主要的路由文件
func init() {
	beego.Notice("##init Login##")


	beego.Router("/login", &controllers.PublicController{}, "get:Login")
	beego.Router("/login", &controllers.PublicController{}, "post:LoginDo")
	beego.Router("/logout", &controllers.PublicController{}, "get:Logout")

	beego.Router("/captcha-id", &controllers.PublicController{}, "get:GetCaptchaId")

	beego.Handler("/captcha/*.png", captcha.Server(240, 110))

}
