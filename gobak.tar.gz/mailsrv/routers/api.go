package routers

import "mailsrv/controllers"

//主要的路由文件
func init() {


	//路由地址前缀
	routebb.prefix="/api"
	routebb.RouteSet("/send-one", &controllers.ApiController{}, "get:SendOne")
	routebb.RouteSet("/send-one", &controllers.ApiController{}, "post:SendOne")

}

