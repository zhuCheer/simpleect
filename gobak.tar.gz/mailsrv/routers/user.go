package routers

import (
	"mailsrv/controllers"
)


//主要的路由文件
func init() {


	//路由地址前缀
	routebb.prefix="/admin/user"
	routebb.RouteSet("/changepwd", &controllers.UserController{}, "get:ChangePwd")
	routebb.RouteSet("/changepwd", &controllers.UserController{}, "post:DoChangePwd")


}
