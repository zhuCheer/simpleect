package routers

import (
	"mailsrv/controllers"
	"github.com/astaxie/beego"
)

type RouteBaby struct {
	prefix string

}
var routebb = &RouteBaby{}

func (rb *RouteBaby) RouteSet(roopath string, c beego.ControllerInterface, mappingMethods ...string){
	beego.Router(rb.prefix+roopath, c, mappingMethods...)
}


//主要的路由文件
func init() {
	beego.Notice("##init main##")



	beego.Router("/", &controllers.MainController{})

	beego.Router("/welcome", &controllers.MainController{}, "get:Welcome")
	beego.Router("/home", &controllers.MainController{}, "get:Home")
	beego.Router("/menus", &controllers.MenusController{}, "get:Menus")
	beego.Router("/abort", &controllers.PublicController{}, "get:AbortPage")


	//apps管理
	beego.Router("/apps", &controllers.MainController{}, "get:AppsList")
	beego.Router("/apps-list", &controllers.MainController{}, "get:AppsListApi")
	beego.Router("/apps-insert", &controllers.MainController{}, "get:AppsInsert")
	beego.Router("/apps-insert", &controllers.MainController{}, "post:AppsInsertDo")
	beego.Router("/apps-edit", &controllers.MainController{}, "get:AppsEdit")
	beego.Router("/apps-edit", &controllers.MainController{}, "post:AppsEditDo")
	beego.Router("/apps-del", &controllers.MainController{}, "post:AppsDelDo")


	//logs管理
	beego.Router("/logs", &controllers.LogsController{}, "get:LogsList")
	beego.Router("/logs-list", &controllers.LogsController{}, "get:LogsListApi")
	beego.Router("/logs-info", &controllers.LogsController{}, "get:LogInfo")
}
