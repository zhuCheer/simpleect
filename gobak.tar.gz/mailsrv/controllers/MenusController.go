package controllers


type MenusController struct {
	BaseController
}

type Menus struct {
	Id int `json:"id"`
	Title  string `json:"title"`
	Spread bool `json:"spread"`
	Icon string `json:"icon"`
	Url string `json:"url"`
	Children  interface{} `json:"children"`
}

/*
datas := []Menus{
		{
			Id:8,
			Title:"222",
			Spread:false,
			Icon:"",
			Url:"http://www.stnts.com",
			Children:""},
		{
			Id:6,
			Title:"222",
			Spread:false,
			Icon:"",
			Url:"http://www.stnts.com",
			Children:Menus{Id:1,Title:"222",Spread:false,Icon:"",Url:"http://www.stnts.com",Children:""}},
		{
			Id:7,
			Title:"222",
			Spread:false,Icon:"",
			Url:"http://www.stnts.com",
			Children:""}}
 */

func (this *MenusController) Menus(){

	datas := []Menus{
		{
			Id:8,
			Title:"项目管理",
			Spread:false,
			Icon:"&#xe628;",
			Url:"",
			Children:[]Menus{
				{Id:1,Title:"业务线",Spread:false,Icon:"",Url:this.URLFor("MainController.AppsList"),Children:""},

			},
		},
		{
			Id:6,
			Title:"提交日志",
			Spread:false,
			Icon:"&#xe628;",
			Url:"",
			Children:[]Menus{
				{Id:3,Title:"执行记录",Spread:false,Icon:"",Url:this.URLFor("Controller.LogsList"),Children:""},
			},
		},
		{
			Id:7,
			Title:"系统配置",
			Spread:false,Icon:"&#xe628;",
			Url:"http://www.stnts.com",
			Children:[]Menus{
				{Id:5,Title:"修改密码",Spread:false,Icon:"",Url:this.URLFor("UserController.ChangePwd"),Children:""},
			},
		},
	}


	this.toJson(datas)
	return
}


