package controllers

import (
	"mailsrv/utils"
	"mailsrv/models"
	"strings"
)

type UserController struct {
	BaseController
}


func (this *UserController) ChangePwd(){


	this.Data["user_name"]=this.sessUserInfo.Name
	this.setTpl("changepwd.html")
}

func (this *UserController) DoChangePwd(){

	history := strings.TrimSpace(this.GetString("history"))
	new_pwd := strings.TrimSpace(this.GetString("new_pwd"))
	new_pwd_again := strings.TrimSpace(this.GetString("new_pwd_again"))

	this.ajaxReturn("","测试数据哦，别想了！！！", 400)

	if new_pwd != new_pwd_again {
		this.ajaxReturn("","两次密码不一致", 400)
	}
	password := utils.String2md5(history)
	username := this.sessUserInfo.Name

	_, err := models.GetOneAdminUser(username, password)
	if err != nil{
		this.ajaxReturn("","原密码错误", 400)
	}

	res := models.ChangeAdminUserPwd(this.sessUserInfo.Id, new_pwd)
	if res != nil{
		this.ajaxReturn("","修改异常", 400)
	}

	this.ClearUserLoginSess()
	this.ajaxReturn(map[string]string{"topurl":this.URLFor("UserController.ChangePwd")},"修改成功", 200)
}