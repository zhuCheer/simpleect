package controllers

import (
	"mailsrv/models"
)

type LogsController struct {
	BaseController
}


/*
应用接入管理
 */
func (this *LogsController) LogsList(){

	appid := this.GetString("appid")
	dostatus := this.GetString("dostatus")
	keyword := this.GetString("kw")
	appModel := models.Apps{}
	allApps,_ := appModel.AllApps()

	this.Data["allApps"] = allApps

	this.Data["appid"] = appid
	this.Data["dostatus"] = dostatus
	this.Data["keyword"] = keyword


	this.setTpl("logs.html")
}

func (this *LogsController) LogsListApi(){
	page, _ := this.GetInt("page")
	appid := this.GetString("appid")
	dostatus := this.GetString("dostatus")
	keyword := this.GetString("kw")
	mailer := models.Mailer{}
	filterParams := &models.MailQueryParam{
		App_id:appid,
		Dostatus:dostatus,
		TitleLike:keyword,
	}

	datas, total := mailer.PageList(filterParams, page)
	this.pageApiJson(datas, total, "", 0)
}

/*
查询指定app信息
 */
func (this *LogsController) LogInfo() {
	id, _ := this.GetInt("id")
	mailer := models.Mailer{}
	info, _ := mailer.GetOne(id)

	this.ajaxReturn(info, "success", 200)
}

