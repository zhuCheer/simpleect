package sysinit


func init() {

	InitDatabase()
}
