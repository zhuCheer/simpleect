package sysinit



import (
	_ "mailsrv/models"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"

)

//初始化数据连接
func InitDatabase() {
	//读取配置文件，设置数据库参数
	//连接名称
	//dbAlias := "default"
	dbName := beego.AppConfig.String("mysqldb")
	dbUser := beego.AppConfig.String("mysqluser")
	dbPwd := beego.AppConfig.String("mysqlpass")
	dbHost := beego.AppConfig.String("mysqlhost")
	dbPort := beego.AppConfig.String("mysqlport")
	dbCharset := "utf8"


	DbConn := dbUser+":"+dbPwd+"@tcp("+dbHost+":"+dbPort+")/"+dbName+"?charset="+dbCharset
	beego.Notice(DbConn)
	// 注册默认数据库
	orm.RegisterDriver("mysql", orm.DRMySQL)
	orm.RegisterDataBase("default", "mysql", DbConn, 10)


	//如果是开发模式，则显示命令信息
	isDev := (beego.AppConfig.String("runmode") == "dev")
	//自动建表
	//orm.RunSyncdb("default", false, isDev)
	if isDev {
		orm.Debug = true
	}
}
